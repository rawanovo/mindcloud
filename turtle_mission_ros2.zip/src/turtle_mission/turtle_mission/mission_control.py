import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from turtle_mission_interfaces.srv import SetDestination
from turtle_mission_interfaces.action import NavigateTo


class MissionControl(Node):
    def __init__(self):
        super().__init__('mission_control')

        self.destination_client = self.create_client(
            SetDestination,
            'set_destination'
        )

        self.navigation_client = ActionClient(
            self,
            NavigateTo,
            'navigate_to'
        )

    def run_mission(self, x, y):
        self.get_logger().info('Waiting for destination validation service...')

        if not self.destination_client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error('Destination service is unavailable.')
            return

        request = SetDestination.Request()
        request.x = x
        request.y = y

        validation_future = self.destination_client.call_async(request)
        rclpy.spin_until_future_complete(self, validation_future)

        response = validation_future.result()

        if response is None:
            self.get_logger().error('Could not validate the destination.')
            return

        self.get_logger().info(response.message)

        if not response.accepted:
            self.get_logger().warn('Mission was not started.')
            return

        
        self.get_logger().info(f'Traveling to destination ({x}, {y}).')

        if not self.navigate_to(x, y):
            self.get_logger().error(
                'Could not complete the destination mission. Not returning home.'
            )
            return

        self.get_logger().info('Destination reached successfully!')

        
        home_x = 5.5
        home_y = 5.5

        self.get_logger().info(
            f'Returning home to ({home_x}, {home_y})...'
        )

        if self.navigate_to(home_x, home_y):
            self.get_logger().info('Mission complete! The turtle is home.')
        else:
            self.get_logger().error('The turtle could not return home.')

    def navigate_to(self, x, y):
        if not self.navigation_client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error('Navigation action server is unavailable.')
            return False

        goal = NavigateTo.Goal()
        goal.x = x
        goal.y = y

        goal_future = self.navigation_client.send_goal_async(
            goal,
            feedback_callback=self.feedback_callback
        )

        rclpy.spin_until_future_complete(self, goal_future)
        goal_handle = goal_future.result()

        if goal_handle is None or not goal_handle.accepted:
            self.get_logger().error('Navigation goal was rejected.')
            return False

        self.get_logger().info(f'Navigation goal accepted: ({x}, {y}).')

        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)

        wrapped_result = result_future.result()

        if wrapped_result is None:
            self.get_logger().error('No navigation result was received.')
            return False

        result = wrapped_result.result

        if result.success:
            self.get_logger().info(result.message)
            return True

        self.get_logger().error(result.message)
        return False

    def feedback_callback(self, feedback_message):
        distance = feedback_message.feedback.distance_remaining
        self.get_logger().info(f'Distance remaining: {distance:.2f}')


def main(args=None):
    rclpy.init(args=args)
    node = MissionControl()

    try:
        print('\n=== TurtleSim Mission Control ===')
        print('Enter a destination between 0 and 11.')
        print('The turtle will return home to (5.5, 5.5).')
        print('Press Ctrl+C to stop the program.\n')

        x = float(input('Enter destination X: '))
        y = float(input('Enter destination Y: '))

        node.run_mission(x, y)

    except ValueError:
        print('Invalid input. Please enter numbers, such as 8 and 6.')
    except KeyboardInterrupt:
        print('\nMission control stopped.')
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()


