import math
import time

import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from geometry_msgs.msg import Twist
from turtlesim_msgs.msg import Pose
from turtle_mission_interfaces.action import NavigateTo


class NavigationServer(Node):
    def __init__(self):
        super().__init__('navigation_server')

        self.callback_group = ReentrantCallbackGroup()
        self.pose = None

        self.pose_subscriber = self.create_subscription(
            Pose,
            '/turtle1/pose',
            self.pose_callback,
            10,
            callback_group=self.callback_group
        )

        self.velocity_publisher = self.create_publisher(
            Twist,
            '/turtle1/cmd_vel',
            10
        )

        self.action_server = ActionServer(
            self,
            NavigateTo,
            'navigate_to',
            execute_callback=self.execute_callback,
            goal_callback=self.goal_callback,
            cancel_callback=self.cancel_callback,
            callback_group=self.callback_group
        )

        self.get_logger().info('Navigation action server is ready.')

    def pose_callback(self, msg):
        self.pose = msg

    def goal_callback(self, goal_request):
        if not (0.0 <= goal_request.x <= 11.0 and
                0.0 <= goal_request.y <= 11.0):
            self.get_logger().warn('Rejected goal: destination is out of bounds.')
            return GoalResponse.REJECT

        return GoalResponse.ACCEPT

    def cancel_callback(self, goal_handle):
        self.get_logger().info('Cancellation requested.')
        return CancelResponse.ACCEPT

    def stop_turtle(self):
        self.velocity_publisher.publish(Twist())

    def execute_callback(self, goal_handle):
        result = NavigateTo.Result()
        feedback = NavigateTo.Feedback()

        target_x = goal_handle.request.x
        target_y = goal_handle.request.y

        self.get_logger().info(
            f'Moving turtle to ({target_x:.2f}, {target_y:.2f}).'
        )

        timeout = time.monotonic() + 120.0

        try:
            while rclpy.ok():
                if goal_handle.is_cancel_requested:
                    self.stop_turtle()
                    goal_handle.canceled()
                    result.success = False
                    result.message = 'Mission cancelled.'
                    return result

                if time.monotonic() >= timeout:
                    self.stop_turtle()
                    goal_handle.abort()
                    result.success = False
                    result.message = 'Mission timed out.'
                    return result

                if self.pose is None:
                    time.sleep(0.05)
                    continue

                dx = target_x - self.pose.x
                dy = target_y - self.pose.y
                distance = math.hypot(dx, dy)

                feedback.distance_remaining = distance
                goal_handle.publish_feedback(feedback)

                if distance < 0.15:
                    self.stop_turtle()
                    goal_handle.succeed()
                    result.success = True
                    result.message = 'Destination reached!'
                    self.get_logger().info(result.message)
                    return result

                desired_angle = math.atan2(dy, dx)
                angle_error = math.atan2(
                    math.sin(desired_angle - self.pose.theta),
                    math.cos(desired_angle - self.pose.theta)
                )

                command = Twist()
                command.angular.z = 4.0 * angle_error
                command.linear.x = min(2.0, 1.5 * distance)

                if abs(angle_error) > 0.3:
                    command.linear.x = 0.0

                self.velocity_publisher.publish(command)
                time.sleep(0.05)

        except Exception as error:
            self.stop_turtle()
            if goal_handle.is_active:
                goal_handle.abort()
            result.success = False
            result.message = f'Navigation failed: {error}'
            self.get_logger().error(result.message)
            return result

        self.stop_turtle()
        result.success = False
        result.message = 'ROS stopped.'
        return result


def main(args=None):
    rclpy.init(args=args)
    node = NavigationServer()
    executor = MultiThreadedExecutor(num_threads=3)
    executor.add_node(node)

    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.stop_turtle()
        executor.shutdown()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
