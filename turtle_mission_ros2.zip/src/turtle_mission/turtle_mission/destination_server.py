import rclpy
from rclpy.node import Node
from turtle_mission_interfaces.srv import SetDestination


class DestinationServer(Node):
    def __init__(self):
        super().__init__('destination_server')
        self.service = self.create_service(
            SetDestination,
            'set_destination',
            self.validate_destination
        )
        self.get_logger().info('Destination validation service is ready.')

    def validate_destination(self, request, response):
        if 0.0 <= request.x <= 11.0 and 0.0 <= request.y <= 11.0:
            response.accepted = True
            response.message = 'Destination accepted.'
        else:
            response.accepted = False
            response.message = 'Destination rejected: coordinates must be between 0 and 11.'

        self.get_logger().info(
            f'Destination ({request.x}, {request.y}): {response.message}'
        )
        return response


def main(args=None):
    rclpy.init(args=args)
    node = DestinationServer()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
