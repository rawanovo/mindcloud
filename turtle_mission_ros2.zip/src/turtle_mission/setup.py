from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'turtle_mission'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
    ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
    ('share/' + package_name, ['package.xml']),
    (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
],
    package_data={'': ['py.typed']},
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='rawan',
    maintainer_email='rawan@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': ['destination_server = turtle_mission.destination_server:main',
        'navigation_server = turtle_mission.navigation_server:main',
        'mission_control = turtle_mission.mission_control:main',
        ],
    },
)
