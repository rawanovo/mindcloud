from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='turtlesim',
            executable='turtlesim_node',
            name='turtlesim'
        ),
        Node(
            package='turtle_mission',
            executable='destination_server',
            name='destination_server',
            output='screen'
        ),
        Node(
            package='turtle_mission',
            executable='navigation_server',
            name='navigation_server',
            output='screen'
        ),
    ])
